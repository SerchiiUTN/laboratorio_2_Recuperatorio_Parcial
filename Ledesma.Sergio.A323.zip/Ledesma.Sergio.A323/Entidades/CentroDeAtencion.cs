﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class CentroDeAtencion
    {
        private int cantRacsPorSuper;
        private List<Empleado> empleados;
        private string nombre;

        public List<Empleado> Empleados 
        { 
            get 
            { 
                return empleados; 
            } 
        }

        public string Nombre
        {
            get 
            { 
                return nombre; 
            }
        }

        public CentroDeAtencion(string nombre, int cantRacsPorSuper)
        {
            this.nombre = nombre;
            this.cantRacsPorSuper = cantRacsPorSuper;
            this.empleados = new List<Empleado>();
        }

        public string ImprimirNomina()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var empleado in Empleados)
            {
                sb.AppendLine(empleado.ToString());
            }
            return sb.ToString();
        }

        public static bool operator !=(CentroDeAtencion c, Empleado e)
        {
            return !(c == e);
        }

        public static bool operator ==(CentroDeAtencion c, Empleado e)
        {
            return c.empleados.Contains(e);
        }

        public static bool operator + (CentroDeAtencion c, Empleado e)
        {
            if (c == e)
            {
                return false;
            }

            if (e is Supervisor)
            {
                if (c.ValidaCantidadDeRacs())
                {
                    c.empleados.Add(e);
                    return true;
                }
                return false;
            }
            else
            {
                c.empleados.Add(e);
                return true;
            }
        }

        public static string operator - (CentroDeAtencion c, Empleado e)
        {
            if (c!=e)
            {
                return "Empleado no encontrado";
            }
                

            e.HoraEgreso = DateTime.Now.TimeOfDay;
            c.empleados.Remove(e);
            return e.EmitirFactura();
        }

        private bool ValidaCantidadDeRacs()
        {
            if(empleados.Count > cantRacsPorSuper)
            {
                return true;
            }
            return false;
        }
    }
}
