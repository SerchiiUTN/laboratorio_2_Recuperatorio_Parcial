﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Rac : Empleado
    {
        public enum EGrupo
        {
            CALL_IN,
            CALL_OUT,
            RRSS
        }

        private EGrupo grupo;
        private static double valorHora;

        public EGrupo Grupo 
        {
            get 
            { 
                return grupo; 
            } 
        }

        public static double ValorHora
        {
            get
            {
                return valorHora;
            }
            set
            {
                if(value > 0) 
                {
                    valorHora = value;
                }    
            }
        }

        private double CalculaBonoDeGrupo()
        {
            switch(Grupo)
            {
                case EGrupo.CALL_OUT:
                    return 0.1f;
                case EGrupo.RRSS:
                    return 0.2f; 
                default:
                    return 0;
            }
        }

        public override string EmitirFactura()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Factura de: {nombre}");
            sb.AppendLine($"Importe a facturar: {Facturar()}");

            return sb.ToString();
        }

        protected override double Facturar()
        {
            double totalHours = base.Facturar();
            double bono = ValorHora * CalculaBonoDeGrupo();
            double valorHoraBonificada = ValorHora + bono;

            return totalHours * valorHoraBonificada;

        }

        static Rac()
        {
            valorHora = 875.90F;
        }

        private Rac() : this("", "", TimeSpan.Zero)
        {
            
        }

        public Rac(string legajo, string nombre, TimeSpan horaIngreso) : this(legajo, nombre, horaIngreso, EGrupo.CALL_IN)
        {
            
        }

        public Rac(string legajo, string nombre, TimeSpan horaIngreso, EGrupo grupo) : base(legajo, nombre, horaIngreso)
        {
            this.grupo = grupo;
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} - {Grupo} - {Legajo} - {Nombre}";
        }
    }
}
