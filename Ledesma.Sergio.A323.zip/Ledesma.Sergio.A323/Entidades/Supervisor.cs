﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Supervisor : Empleado
    {
        private static float valorHora;

        public float ValorHora
        {
            get 
            { 
                return valorHora; 
            }
            set
            {
                if (value > 0)
                {
                    valorHora = value;
                }
            }
        }

        public override string EmitirFactura()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Factura de: {nombre}");
            sb.AppendLine($"Importe a facturar: {Facturar()}");

            return sb.ToString();
        }

        protected override double Facturar()
        {
            double totalHours = base.Facturar();

            return totalHours * ValorHora;
        }

        public static implicit operator Supervisor(string legajo)
        {
            return new Supervisor(legajo);
        }

        static Supervisor()
        {
            valorHora = 1025.50F;
        }

        private Supervisor() : this("")
        {

        }

        private Supervisor(string legajo) : this(legajo, "n/a", new TimeSpan(09,00,00))
        {

        }

        public Supervisor(string legajo, string nombre, TimeSpan horaIngreso) : base(legajo, nombre, horaIngreso)
        {

        }

        public override string ToString()
        {
            return $"{this.GetType().Name} - {Legajo} - {Nombre}";
        }
    }
}
