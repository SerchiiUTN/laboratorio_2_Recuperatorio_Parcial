﻿using System.Data.Common;

namespace Entidades
{
    public abstract class Empleado
    {
        protected TimeSpan horaEgreso;
        protected TimeSpan horaIngreso;
        protected string legajo;
        protected string nombre;

        public TimeSpan HoraEgreso
        {
            get
            {
                return horaEgreso;
            }
            set
            {
                TimeSpan valor;

                valor = ValidaHoraEgreso(value);

                horaEgreso = valor;
            }
        }

        public TimeSpan HoraIngreso
        {
            get
            {
                return horaIngreso;
            }
        }

        public string Legajo
        {
            get
            {
                return nombre;
            }
        }

        public string Nombre
        {
            get
            {
                return nombre;
            }
        }

        public abstract string EmitirFactura();

        protected Empleado(string legajo, string nombre, TimeSpan horaIngreso)
        {
            this.horaIngreso = horaIngreso;
            this.legajo = legajo;
            this.nombre = nombre;
        }

        protected virtual double Facturar()
        {
            double totalHours;
            TimeSpan diferencia;
            
            diferencia = horaEgreso - horaIngreso;
            totalHours = diferencia.TotalHours;

            return totalHours;
        }

        public static bool operator !=(Empleado emp1, Empleado emp2)
        {
            return !(emp1 == emp2);
        }

        public static bool operator ==(Empleado emp1, Empleado emp2)
        {
            return (emp1.Legajo == emp2.Legajo);
        }

        private TimeSpan ValidaHoraEgreso(TimeSpan horaEgreso)
        {
            if(horaEgreso > HoraIngreso)
            {
                return horaEgreso;
            }
            else
            {
                return DateTime.Now.TimeOfDay;
            }
        }
    }
}